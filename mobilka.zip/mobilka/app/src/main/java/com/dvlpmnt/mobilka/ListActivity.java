package com.dvlpmnt.mobilka;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.content.Context;

import com.dvlpmnt.mobilka.databinding.ActivityListBinding;

import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity {

    ActivityListBinding binding;
    ListData listData;
    List<ListData> listDataArray = new ArrayList<>();
    List<View> listDataViewArray = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.buttonExitList.setOnClickListener(new View.OnClickListener() { // Кнопка возвращения на главный экран
            @Override
            public void onClick(View v) {
                Intent intentBack = new Intent(ListActivity.this, MainActivity.class);
                startActivity(intentBack);
            }
        });

        Intent intent = getIntent();
        int PatAlgChoice = intent.getIntExtra("choice", 1);

        if (PatAlgChoice == 1){
            binding.textViewHeader.setText("Паттерны");

            String[] nameList = {"Bridge", "Adapter", "Proxy", "Builder", "Factory", "Abstract Factory", "Singleton", "Decorator",
                    "Flyweight"};
            String[] typelist = {ListData.TYPE_BEHAVIORAL, ListData.TYPE_BEHAVIORAL, ListData.TYPE_BEHAVIORAL, ListData.TYPE_STRUCTURAL,
                    ListData.TYPE_STRUCTURAL, ListData.TYPE_STRUCTURAL, ListData.TYPE_CREATIONAL, ListData.TYPE_CREATIONAL, ListData.TYPE_CREATIONAL};
            int[] idList = {1, 2, 3, 4, 5, 6, 7, 8, 9};

            for (int i =0; i < nameList.length; i++){
                listData = new ListData(ListActivity.this, nameList[i], typelist[i]);
                listDataArray.add(listData);
                listDataViewArray.add(listData.getView());
                binding.linearLayout.addView(listDataViewArray.get(i));
            }

            CompoundButton.OnCheckedChangeListener checkedChangeListener = new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked){

                        for (int i = 0; i < listDataArray.size(); i++){
                            binding.linearLayout.removeView(listDataViewArray.get(i));
                        }

                        for (int i =0; i < listDataArray.size(); i++){
                            if (binding.checkBoxPatterns.checkBoxPatternsBehavioral.isChecked()){
                                if (listDataArray.get(i).getType() == ListData.TYPE_BEHAVIORAL){
                                    binding.linearLayout.addView(listDataViewArray.get(i));
                                }
                            }
                            if (binding.checkBoxPatterns.checkBoxPatternsStructural.isChecked()){
                                if (listDataArray.get(i).getType() == ListData.TYPE_STRUCTURAL){
                                    binding.linearLayout.addView(listDataViewArray.get(i));
                                }
                            }
                            if (binding.checkBoxPatterns.checkBoxPatternsCreational.isChecked()){
                                if (listDataArray.get(i).getType() == ListData.TYPE_CREATIONAL){
                                    binding.linearLayout.addView(listDataViewArray.get(i));
                                }
                            }
                        }
                    }
                    else {
                        for (int i =0; i < listDataArray.size(); i++){
                            if (!(binding.checkBoxPatterns.checkBoxPatternsBehavioral.isChecked())){
                                if (listDataArray.get(i).getType() == ListData.TYPE_BEHAVIORAL){
                                    binding.linearLayout.removeView(listDataViewArray.get(i));
                                }
                            }
                            if (!(binding.checkBoxPatterns.checkBoxPatternsStructural.isChecked())){
                                if (listDataArray.get(i).getType() == ListData.TYPE_STRUCTURAL){
                                    binding.linearLayout.removeView(listDataViewArray.get(i));
                                }
                            }
                            if (!(binding.checkBoxPatterns.checkBoxPatternsCreational.isChecked())){
                                if (listDataArray.get(i).getType() == ListData.TYPE_CREATIONAL){
                                    binding.linearLayout.removeView(listDataViewArray.get(i));
                                }
                            }
                        }
                    }

                }
            };

            binding.checkBoxPatterns.checkBoxPatternsBehavioral.setOnCheckedChangeListener(checkedChangeListener);
            binding.checkBoxPatterns.checkBoxPatternsStructural.setOnCheckedChangeListener(checkedChangeListener);
            binding.checkBoxPatterns.checkBoxPatternsCreational.setOnCheckedChangeListener(checkedChangeListener);

        }
//        else {
//            binding.textViewHeader.setText("Алгоритмы");
//            binding.linearLayout.removeView(binding.checkBoxPatterns);
//
//            String[] nameList = {"Пузырьковая сортирвка", "Придурковатая сортировка", "Сортировочная сортировка", "Цветочная сортировка", "Шизанутая сортировка"};
//
//            for (int i =0; i < nameList.length; i++){
//
//                listData = new ListData(nameList[i]);
//                dataArrayList.add(listData);
//
//            }
//
//            listAdapter = new ListAdapter(ListActivity.this, dataArrayList);
//            binding.listView.setAdapter(listAdapter);
//        }
    }
}