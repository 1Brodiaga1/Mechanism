package com.dvlpmnt.mobilka;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import androidx.viewpager.widget.ViewPager;

import com.dvlpmnt.mobilka.databinding.ActivityDetailBinding;

public class DetailActivity extends AppCompatActivity {


    ActivityDetailBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Intent intent = getIntent();
        int buttonChoice = intent.getIntExtra("ButtonChoice", 1);
        String name = intent.getStringExtra("Name");
        String type = intent.getStringExtra("Type");

        ViewPager viewpager = findViewById(R.id.viewpager);

        viewpager.setAdapter(new SampleFragmentPagerAdapter(getSupportFragmentManager(), DetailActivity.this));

        binding.tablayout.setupWithViewPager(viewpager);
//        if (buttonChoice == 1){
//            binding.textViewHeaderDetailName.setText(name);
//            binding.textViewHeaderDetailType.setText(type);
//            binding.textViewHeaderDetail.setText("Описание");
//
//        }
//        else if (buttonChoice == 2){
//            binding.textViewHeaderDetailName.setText(name);
//            binding.textViewHeaderDetailType.setText(type);
//            binding.textViewHeaderDetail.setText("Вид");
//        }
//        else {
//            binding.textViewHeaderDetailName.setText(name);
//            binding.textViewHeaderDetailType.setText(type);
//            binding.textViewHeaderDetail.setText("Программный код");
//        }
    }
}